# CS574_Computer_Security Assignment 01
James Foti
Red ID: 820124143
CS 574
Professor Song
2/24/2020

Note: For question 3, I worked out the solutions using tables through google docs and simply took a screenshots of them. The photos
don't appear in the pdf but they are visible through jupyter notebook. You can also view them in \Images folder. 